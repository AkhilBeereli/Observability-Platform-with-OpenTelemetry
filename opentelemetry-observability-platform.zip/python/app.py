from flask import Flask
from time import sleep
import random, os

# OpenTelemetry
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.flask import FlaskInstrumentor

endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4318")
provider = TracerProvider(resource=Resource.create({"service.name": "otel-demo-app"}))
processor = BatchSpanProcessor(OTLPSpanExporter(endpoint=endpoint))
provider.add_span_processor(processor)
trace.set_tracer_provider(provider)

app = Flask(__name__)
FlaskInstrumentor().instrument_app(app)

@app.get("/")
def index():
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("work"):
        sleep(random.uniform(0.01, 0.2))
    return {"status": "ok", "message": "otel demo"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
