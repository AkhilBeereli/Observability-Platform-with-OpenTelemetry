# Observability Platform with OpenTelemetry

Production-style scaffold featuring **OpenTelemetry Collector**, **Prometheus**, **Grafana**, and a sample **Python** service instrumented with OTEL SDK.

## Quickstart
```bash
docker compose up -d
# Open Grafana at http://localhost:3000 (admin/admin)
```
